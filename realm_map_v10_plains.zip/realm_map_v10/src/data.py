AREAS = r"""
Abbatoir Asylum|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;#2 s;se;#6 e;#3 se;#3 s;sw;#2 s;scan/move to "Afloat on the ocean";east
Abishai's Morgue|#9 w;sw;#4 w;s;sw;w;w;open s;s;s;sw;s;window
Along the Forest Path|#7 w;sw;s;s
City of Aurora|#6 s;ne;s;s;se;e;e;s;#2 sw;s;#4 sw;#4 s;#2 sw;s;#2 sw;s;sw;#5 s;#3 e;s;s
Antall, the Lost Harbor|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;#2 s;se;#6 e;#3 se;#3 s;sw;#2 s;se
Ashen Forest|#13 e
Astral Plane|#8 u;n
Azure Sea|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e
Badlands|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#3 s;#3 se;n
Barren Peaks|nw;w;w;#4 n;e;look painting;open n;n;#28 w;#3 s
Barren Wastes|#8 e;#2 se;s;#4 se;#2 s;sw;w;sw;#2 s;#3 se;sw;s;#2 sw;s;se;sw;#2 se;sw;#2 se;e;se;s;sw;w;sw;nw;w;#2 nw;w;n;se;scan/move to 'A crumbling dusty stone';dig down;d
Barrik's Keep|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;s;s;sw;sw;s;s;ne;ne;n;nw;w;nw;nw;w;#3 nw;#3 w;nw;nw;#3 w;s;e;#3 ne;se;#4 e;se;se;#3 e;n;#5 ne;#4 nw;ne;e;#3 ne;#4 e;#4 n;#3 e;n;nw;nw;w;w;#4 sw;#3 w;nw;w;w;#4 sw
Bartok Grove|#6 w;sw;sw;#5 w;s
Black Dagger Outlaws Hideout|#8 w;sw;s;#2 sw;s;#2 w;#2 sw;w;se;sw;se;sw;se;#2 sw;se;#2 s;sw;s;sw;s;se;s;sw;#2 s;sw;e
Blasted Lands|#8 e;se;se;s;#4 se;s;s;sw;w;sw;s;s;#3 se;sw;w;w;sw;s;s;e;
Blood Sea|#52 w
City of Salburg|#8 n;ne;w;n;ne;nw;e;ne;n;e;ne;#2 n;#2 ne;w;#2 nw;#3 n;ne;e;
Cold Comfort|#4 s;w;#2 n;give 5k coins receptionist;unlock n;open n;#3 n;ne;n;ne;n;enter;d;e;#2 n (wander, scry for se exit, go se)
Coral Depths|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;ne;#3 e;s;se;s;#2 e;s;#2 e;
Corruption of Anciastra|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;s;e
Crystalmir Lake|nw;#2 w;#4 n;e;look painting;open n;n;#28 w;#2 s;w;sw;#2 s;#4 w;#2 nw;#3 w;#5 sw;n
Curse of Prosperity|#7 w;sw;s;w;#2 sw;s;#2 w;se;#3 w;sw;se;sw;se;#2 sw;se;#2 s;sw;s;sw;s;se;s;sw;#2 s;sw;s;sw;#3 s;e
Cursed Lands|s;s;s;s;s;s;ne;s;s;se;e;e;s;sw;sw;s;e;e;u;e;e;e;s;s;s;se;e;e;e;s;se;se;s;sw;s;s;w;sw;d;nw;s;e;e;se;se;e;se;se;se;se;sw;sw;sw;sw;sw;sw;w;w;nw;nw;ne;e;nw;n
Darkhaven Art Gallery|#4 s;w;n;n;give 5000 coin recep;unlock n;open n;n;drop key
D'Morian Lands|#32 w;#6 s
Daichaaal|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#3 s;#5 se;#3 s;d;s;se;s;#3 se;e;#3 s;ne;e;s;#2 se;#3 e;#2 se;#3 e;se
Dawn to Dusk|#7 w;sw;s;w;sw;sw;s;w;w;se;w;w;w;sw;se;sw;se;sw;sw;se;s;s;sw;s;sw;s;se;s;sw;s;s;sw;s;sw;s;s;s;sw;n
Desert of Despair|#8 e;se;se;s;#4 se;s;s;sw;w;sw;s;s;#3 se
Domain of the World Eater|#13 e;#3 s;w;s;#2 w,n,#2 w,#2 s,se,#2 e,ne,w,s,#3 d;scan/scry for "Formless Void" maze.
Dragon Cult|#4 s;e;n;say idolizer of dragons
Dragon Tower|#6 s;ne;s;s;se;e;e;s;sw;sw;s;#10 sw;w;u;s;e;e;se;se;s;s;sw;nw;nw;#3 w;sw;w;sw;se;sw
Dragon's Pass|#6 s;ne;s;s;se;e;e;s;sw;sw;s;#5 sw;nw;#5 n;ne;n;e;se;se;
Dragontail Glen|nw;#2 w;#4 n;e;look painting;open n;n;#28 w;#2 s;w;sw;#2 s;#4 w;#2 nw;#3 w;#5 sw;n;d;#2 w;#2 n;#3 w;#2 n
Drow City|#6 n;#6 e;se;e;ne;ne;e;nw;n;n;ne;ne;w;nw;nw;#3 n;ne;n;nw;#3 n;ne;ne;n;nw;w;nw;nw;w;#3 nw;#3 w;nw;nw;#3 w;s;#3 w;#3 n;ne;open d;d
The Dungeon|#8 e;#2 se;s;#4 se;#2 s;sw;w;sw;#2 s;#3 se;sw;s;#2 sw;w;#2 sw;s;sw;s;#2 se;s;#5 e;#3 n;#2 w;n;d;pick e;open e;e;d
The Dunhill Demesnes|nw;w;w;#4 n;e;look painting;open n;n;n;#57 w;ne;
Dwarven Catacombs|#8 e;se;se;s;#3 se;e;ne;ne;n;ne;ne;n;nw;n;ne;w;push leaves;pull leaves;e;e;n;n;u;open u;u;open u;u;e;d;d;#4 n;open n;n;open n;n;d
Dylan's Area|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 sw;u;#3 w;s;sw;d;#3 w;#3 n;w;#2 s;#2 sw;#2 w;sw;#2 nw;sw;w;sw;#2 s;sw;tree;#2 e;#3 se;#4 s;#3 e;s;#2 w;open w;w;n;#2 u;#2 s
Elemental Canyon|#13 s;e;e;u;u;w;sw;w;sw;d;d;sw;sw;#4 s;e;u;u;e;u;nw;
Emerald Hills|#8 e;se;se;s;#4 se;s;s;sw;w;sw;#3 s;sw;se;u;se;e
Ezard's Fields|#9 w;nw;w;w;nw;w;n;n;nw;nw;ne
Fire Station|#8 e;#3 ne;#3 e;ne;se;e;ne;#3 se;ne;e;#2 ne;n;se
Florebit in Imm.|#9 w;#2 nw;n;w;nw;w;#2 nw;#8 w;nw;#16 w;n
Forest of Tears|#7 w
Forgotten Woods|#8 n;ne;w;n
From The Stars|nw;w;w;#4 n;e;l painting;open n;n;n;w;w;n;#37 w;n;e
Glimwinkle's Windmill|#13 e;#3 s;#3 e;#2 ne;#3 se;e;s;e;
Graveyard|#9 w;sw;#4 w;s;sw;w;w;open s;s
Great Eastern Desert|#8 e;se;se;s;#4 se;s;s;sw;w;sw;s;s;#3 se;sw;w;w;sw;s;s;e
Green Forest|#6 n;#6 w;nw
Halls of Knowledge|#3 e;s;d
Haven of Everlasting Light|#6 w;#2 sw;#5 w;#4 nw;#3 ne;#2 n;#3 nw;w;#4 sw;w;#2 nw;w;nw;n;#4 ne;#4 n;#2 nw;#2 w;#4 sw;s;#2 se;n
High Tower of Sorcery|#6 s;ne;s;s;se;e;e;s;sw;sw;s;#5 sw;nw;#5 n;ne;n;e;se;se;e;s;se;sw;#4 s;sw;sw;s;se;w;w;nw;sw;n;n;sw;w;sw;n;nw;ne;n
Intrigues of the Miden'nir|#13 s;e;sw
Isle of the Monkeys|#3 e;s;d;open w;#3 w;open w;#6 w;#2 examine portal;enter
Keep of Belial|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;#2 s;#2 sw;#2 s;sw
Keep of Mahn-Tor (Keep)|godag;n;n;ne;n;ne;n;enter;d;e;n;u;u
Keep of Mahn-Tor (Ogre Village)|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;s;s;sw;sw;s;s;ne;ne;n;nw;w;nw;nw;w;#3 nw;#3 w;se;w;sw;w;u;nw;#3 w;#3 nw;#3 w;sw
Kilgharrah's Cave|Inside KoTR, at entrance to Swirling Mist maze go: n;s;d
King's Castle|#13 e;#3 s;#3 e;ne;ne;#3 se;e;s;s;sw;s;se;s;se;e;e;ne;ne;e
Kingdom of Juargan|#6 n;#3 nw;w;n;#4 e;s;w;sw;nw;n;ne;u;ne;ne;u;ne;u;ne;nw;w;u;ne;ne;u;w;u;ne;w;#4 sw;#4 w;d;nw;nw;sw;u;#4 w;u;w;w;n;e;e
Kontaur|#26 w;#5 s;
Knights of the Round|#4 s;w;n;n;give 5000 coin recep;unlock n;open n;n;drop key;n;w;nw;w;nw;w;sw;w;enter
La Chute D'eau De L'ancients|#6 n;#6 e;se;e;ne;ne;e;nw;n;n;ne;ne;w;nw;nw;e;n;n;ne;n;ne;w;w;chop;se;chop;sw;chop;w;chop;w;chop;s;chop;sw;chop;w;chop;nw;chop;w;chop;w;chop;nw;ne;
Lake of Tich'Pyga|#7 w;nw;n;n;
Lamechs Abandoned Mansion|#6 s;ne;#2 s;se;#2 e;s;#2 sw;u;nw;ne;#2 w;sw;#3 s;#2 se;ne;e;sw;s;ne;
Land of the Fire Newts|#8 e;#2 se;#2 s;se;s;#4 e;#2 n;e;ne;#2 n;e;s
Machine Dreams|#13 e;#3 s;w;s;w;w;n;w;w;s;s;se;e;e;ne;w;s;d
MacMillan Family Farm|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#10 sw;#2 w;#2 sw;nw;
Major Oak|#6 w;#2 sw;#5 w;nw;nw;ne
Miden'nir|#7 s
The Mire|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#10 sw;w;u;s;#2 e;#2 se;#2 s;sw
Mithril Hall|#6 s;ne;#2 s;se;#2 e;s;#2 sw;u;nw;ne;#2 w;sw;#3 s;#2 se;sw;#2 u;w;nw;#4 w;n;open passage;n;e;n;n;w;d;e;e;n;
A Moment in Nature|#3 e;s;d;open w;#3 w;open w;#6 w;enter
Morgul Vale|nw;w;w;#4 n;e;look painting;open n;n;#49 w;#9 s;w;sw;#2 s;u;#2 s;#2 w;#2 sw;s;se;sw
Moria|#8 e;se;se;s;s
Mountain of Lost Souls|nw;w;w;#4 n;e;look painting;open n;n;#49 w;#8 s;sw;#5 w;sw;sw;nw;#3 w;d;sw;s;s;e;ne;nw;u;ne;u;n;ne;
Mountains of Desolation|#8 e;#2 se;s;#3 se;e
Mulciber's Forge|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#3 s;se;s;#4 se;#3 s;d;s;se;s;#3 sw;u;n;w;u;ne;nw;d
Nevermore|#8 n;ne;w;n;ne;nw;e;ne;n;e;ne;#2 n;#2 ne;#2 e;n;#3 ne;e;ne;n;
New Hope Farm|#6 w;sw;sw;#5 w;#2 s;e;se
New Ofcol|#6 n;#3 nw;w;#4 n;#2 e
Northern Plains|nw;#2 w;#4 n;e;look painting;open n;n
Ocean Keep|#8 e;#3 ne;#3 e;ne;e;ne;e;e;#5 n;ne;e;ne;e;se;e;ne;#3 n;ne;
Ockwater Fens|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 sw;u;#3 w;s;sw;d;#3 w;#3 n;#2 w;sw;w;#3 n;#2 ne;nw
Octopus Garden|#6 s;ne;s;s;se;e;e;s;sw;sw;s;e;e;u;#3 e;s;s;se;e;ne;d
Ofcol|#6 n;#3 nw;w;n
Old Marsh|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 sw;u;#3 w;s;sw;d;#3 w;#3 n;w;#2 s;#2 sw;#2 w;sw;#2 nw;sw;w;sw;#2 s;sw;tree;#2 e;#3 se
Old Pottswort's Fields|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#5 sw;nw;n;#2 ne;e;ne;ne;e;n;ne;n;n;n;n;ne;n;se
Old Thalos|#41 w;#7 n;w;w
Olympus|#8 u;n;finditem pearl-wand;unlock n;open n;n;track Juna (say will you take me to olympus?)
Otherland|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;#3 s;se;#3 e;s;#2 se;#3 s;sw;w;sw;d;nw;s;#2 e;#2 se;w
Pixie Forest|#6 n;#6 e;se;e;#2 ne;e;nw;#2 n;#2 ne;nw
Raven Tor|#6 n;#3 nw;w;n;#4 e;s;w;sw;nw;n;ne;u;#2 ne;u;ne;u;ne;nw;w;u;#2 ne;u;w;u;ne;se;#2 e;#2 se;e;d;ne
Realm of Worship|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;ne;n;ne;#5 n
Redferne's Residence|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 sw;u;#3 w;s;sw;d;#3 w;#3 n;w;#2 s;#2 sw;#2 w;sw;#2 nw;sw;w;sw;#2 s;sw;tree;#2 e;#3 se;#4 s;#3 e;s;#2 w;open w;w
Reign of Madness|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;#2 s;#2 sw;#2 s;#2 ne;n;nw;w;#2 nw;w;#3 nw;#3 w;#2 nw;#3 w;s;e;#3 ne;se;#4 e;#2 se;#3 e;n;#5 ne;#4 nw;ne;e;#3 ne;#4 e;#4 n;#3 e;n;#2 nw;#2 w;#4 nw;scry/move to room with a down exit; d
Revelation City|#6 n;#6 e;se;e;#2 ne;e;nw;#2 n;#2 ne;w;#2 nw;#3 n;ne;n;nw;#3 n;#2 ne;n;nw;w;#2 nw;w;#3 nw;#3 w;#2 nw;#3 w;#5 nw;w;n
Scourge of Time|#8 u;n;unlock n;open n;n;track Malsangre (say back in time)
Sea of Sorrows|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;#3 s;se;#3 e;s;#2 se;#3 s;sw;w;sw;d
Sentinel|#9 w;nw;nw;n;w;nw;w;nw;w;s;s;
Serpentine Coils|#6 n;#3 nw;#2 n;#2 nw;n;ne;n;ne;#2 n;#2 ne;#2 n;ne;n;#2 nw;#3 n;ne;n;nw;#3 n;#2 ne;n;nw;w;#2 nw;w;#3 nw;#3 w;#2 nw;#3 w;s;e;#3 ne;se;#4 e;#2 se;#3 e;n;#5 ne;#4 nw;ne;e;d
Sesuadra's Rift|#42 west;#7 n;enter;sw;enter;s;w;s;onslaught
Seth's Fortress|#6 s;ne;s;s;se;e;e;s;sw;sw;u;nw;ne;w;w;sw;#3 s;se;se;ne;e;sw;s;#3 e;u;u
Shadar Logoth|#13 e;#3 s;#3 e;ne;ne;#3 se;e;s;s;sw;s;se;s;se;e;e;ne;ne;e;sw;se;e;ne;ne;e;e;ne;n;n;n;n;sw;s;w;n;ne;n;n;w;w
Shadow Grove|#7 n
Shadowport|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 sw;u;#2 w;n;nw;#2 n;sw;s;sw;se;e;ne;open wall;#3 n;w;open w;#2 w;n;w;#2 n;open d;d;d
Spectrum|godag;n;e;se;e;se;e;ne;enter
Shai'ghool|#8 e;#3 ne;#3 e;ne;e;ne;e;e;n;n;e;ne;
Shattered Refuge|#9 s;w;#3 s;w;
Shattered Temple of Naetrelle|#8 e;#2 se;s;#4 se;#2 s;sw;w;sw;#2 s;#3 se;sw;#2 w;sw;#6 w;s;ne
The Shire|#9 w;nw;w;w;nw
Silvermoon Outpost|#51 w;#3 s;sw;#5 s;#7 sw
The Slime Pit|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;#2 s;#2 sw;#2 s;#2 ne;n;nw;w;#2 nw;w;#3 nw;#3 w;#2 nw;#3 w;#5 nw;#2 w;sw;w;#2 u;#3 n;nw;#2 d;nw;n;#2 w;nw;u;#3 w;nw;w;se
Southern Mountain Range|#6 s;ne;#2 s;se;#2 e
Southern Plains|#8 s;#2 w;say story
Steading of the Hill Giants|#6 s;ne;#2 s;se;#2 e;s;#2 sw;u;nw;ne;#2 w;sw;#3 s;sw;n
Tayalardian Rangelands|#8 e;#2 se;s;#4 se;s;s;sw;w;sw;s;s;#3 se;sw;w;w;sw;#5 w;#3 n
Temple of the Moon|nw;w;w;#4 n;e;look painting;open n;n;#49 w;#8 s;sw;#3 w;n
Thalos|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 se;#4 e;#3 s
Castle of Rol Na Feinne|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#5 sw;nw;#5 n;ne;n;e;n;ne;#2 n
Tipsy Lizard Tavern|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#10 sw;w;u;s;#2 e;#2 se;#2 s;sw;#2 nw;#3 w;sw;w;#4 sw;#4 s;se;s;sw;s;sw;w;#6 sw;s;#2 sw;e
Tower of Despair|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 sw;u;#3 s;sw;s;sw;w;#3 u
Thul Ab'hara|#8 e;se;se;s;#4 se;s;s;sw;w;sw;s;s;#3 se;sw;s;sw;sw;w;sw;sw;nw;d;d;sw;d;s;#3 se;s;sw;se;s;w
Tower of Enlightenment|#8 n;ne;w;n;nw;w;s;w;#2 nw;n;nw;#2 n;nw;w;nw;ne;#2 n;nw;ne;n;nw;sw;nw;n;#3 nw;ne;e;nw;n;w;#2 n;nw;w;n;sw;w;nw;#2 w;#2 sw;w;sw;w;d;w;sw
Tower of Zenothir|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;s;s;e;se;se;#4 e;n;nw;n;n;sw;e;ne;s;s;se;s;se;s;e;e;se;ne
Town of Solace|nw;#2 w;#4 n;e;look painting;open n;n;#23 w;#3 n
Transylvania|#13 s;#2 e;#2 u;e;#3 se;d;s;#4 se;e;se;e;ne;nw;n;u;#2 n
Tree of Life|#50 w;#5 s;#3 w;
Treetops and Canopy|#9 w;nw;nw;#18 w;u
Troll Den|#6 n;#6 e;se;e;#2 ne;#2 e;ne;e;s;w;sw
Tullfuhrzky Manor|nw;w;w;#4 n;w;look painting
Underworld|#26 w;#7 s;e;s;e;s;d;s;give 50000 coins Wicorith
Unholy Grounds|nw;#2 w;#4 n;e;look painting
Valley of Crucifixion|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;#3 s;se;#3 e;s;#2 se;#3 s;sw;w;sw;d;nw;s;#2 e;#2 se;w;nw;sw;w;s;e
Valley of Mysts|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;#2 s;e;#2 se;#4 e;n;nw;#2 n;sw
Valley of the Elves|nw;w;w;#4 n;e;look painting;open n;n;#30 w;s;s;#15 w
Village of Edo|nw;w;w;#4 n;e;look painting;open n;n;#26 w;n;n;ne;nw;n;nw;w;w;#6 n;nw;n;ne;n;nw;ne;n;n;ne;nw;w;
Village of Tar'pa Cithm|nw;w;w;#4 n;e;look painting;open n;n;#28 w;#3 s;#3 d;#5 w;nw;nw;#3 w;#4 sw;#3 nw;#3 w;sw;s;e
The Von Deusen Mausoleum|#8 e;se;se;s;#4 se;s;s;sw;n;n;nw;pull branch;n
Warehouse|#4 w;n;n;open sw;sw;open s;s;open s;s
Wastelands|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#3 s;se
Wendle Mansion|#8 n;nw;w;n
White Pine Camp|#8 e;#3 ne;#3 e;ne;se
Wild Tundra|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;#3 s;se;#3 e;s;#2 se;#3 s;sw;w;sw;d;nw;s;#2 e;#2 se;w;nw;sw;#2 w;s;d
The Wilds|#8 e;se;se;s;#4 se;s;s;sw;w;nw;nw;u;sw;nw
Winterlight Island|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#4 sw;#4 s;#5 se;#2 s;d;s;se;s;#3 se;#3 e;#2 s;#2 e;d;se;ne;s;d;se;s
The Wolf's Den|#6 n;#3 nw;n;n;nw;nw;n;ne;n;ne;n;n;ne;ne;n;e
Wyvern's Tower|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;s;s;sw;#3 w;ne;
The Ziggurat|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#2 e;u;#3 e;#3 s;se;#3 e;s;#2 se;#3 s;sw;w;sw;d;nw;s;#2 e;#2 se;w;nw;sw;w;s
"""
HOMETOWNS = r"""
The Burrows (Halfling)|#9 w;nw;#2 w;nw;#3 n;#2 w;#3 n;#2 e
City of Eldestra (Half-Elf)|#13 e;ne;nw;w;ne;e;ne;#2 e;s;#2 e;s;se;e;s
City of Iniquity (Drow)|nw;#2 w;#4 n;e;look painting;open n;n;#28 w;#2 s;#4 e;d
Island of Irrybis (Elf)|nw;#2 w;#4 n;e;look painting;open n;n;#62 w;nw;#2 ne;nw;ne;#2 n;nw;n;d
Keep of Lomar (Human)|#6 n;#6 w;sw;w;n;ne;nw;n
Mathlaan Lagoon (Sea-Elf)|#8 e;#3 ne;#3 e;ne;e;ne;#2 e;#5 n;ne;e;ne;e;se;e;ne;#3 n;ne;#2 d;#12 w;se
Mount Krozloy (Half-Orc)|#6 n;#3 nw;w;n;#4 e;s;w;sw;nw;n;ne;u;#2 ne;u;ne;u;ne;nw;w;u;#2 ne;u;w;u;ne;w;#4 sw;#4 w;d;#2 nw;sw;u;#4 w;u;#2 w;n;#2 e;open n;n
Opallinoc (Half-Ogre)|nw;#2 w;#4 n;e;look painting;open n;#2 n;#60 w;n
Qetag's Reach (Dwarf)|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;#2 s;#2 sw;#2 s;#2 ne;n;nw;w;#2 nw;w;#3 nw;#3 w;#2 nw;#3 w;#5 nw;#2 w;sw;w;#2 u;#3 n;nw;#2 d;nw;#2 n;#2 nw;w;#2 n;d
Reomyr Village (Pixie)|#8 n;ne;w;n;ne;nw;e;ne;n;e;ne;#2 n;#2 ne;#2 e;n;ne;nw;w;#2 n;u
Ruins of T'man (Half-Troll)|#8 e;#2 se;s;#4 se;#2 s;sw;n;e
The Sands of Teracchei (Gith)|#8 u;e
Tribal Swamplands (Lizardmen)|#6 s;ne;#2 s;se;#2 e;s;#2 sw;s;#10 sw;w;u;s;#2 e;#2 se;#2 s;sw;#2 nw;#3 w;sw;w;#4 sw;#4 s;se;s;sw;s;sw;w;#2 sw;#5 s;se;#2 e;se;e;se;s;sw;e
Vale of Nidaros (Gnome)|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;#2 s;e;#2 se;#4 e;n;nw
"""
EAST_PAINTING = """e;e;e;e;e;e;e;e;ne;ne;ne;e;e;e;ne;e;ne;e;e;n;n;n;n;n;ne;e;ne;e;se;e;ne;n;n;n;ne;e;e;se;sw;w;ne;ne;ne;ne;nw;n;n;nw;u;nw;nw;nw;nw;nw;n;n;u;nw;w;nw;w;n;e;e;e;e;e;e;e;se;e;ne;e;ne;ne;se;se;e;e;e;se;se;e;se;s;s;se;s"""
WEST_PAINTING = "n;n;n;n;n;n;nw;nw;nw;n;n;nw;nw;sw;n"


# Directions you gave for places that had none (condensed to numbered quantities)
MORE_DIRECTIONS = '''
Notre Dame de Sioux|nw;#2 w;#2 n
Sonoria|nw;#2 w;#5 n
Guild of Origin|#2 ne;e;ne;nw
Guild of Spirit|nw;w;n
Guild of Nature|#3 s;e;s
V'laresch|#9 w;nw;#2 w;nw;w;#2 n;#3 nw;w;#4 sw;w;#2 nw;w;sw;#13 w;n
Falcon's Nest Tavern|#9 w;nw;#2 w;nw;w;#2 n;#3 nw;w;#4 sw;w;#2 nw;w;nw;n;#4 ne;#2 n;w
Darkhaven Marina|#6 s;ne;s
Blackcoggle Manor|#9 w;nw;#2 w;nw;w;#2 n;#3 nw;w;#2 sw;se
The Grimdog Port Authority|#9 w;#2 nw;n;w;nw;w;#2 nw;#8 w;nw;#3 w;nw;w;#2 nw;#2 w;#2 sw;w;sw;#4 w;#2 nw;n;nw
Northern Trade Route|#6 n;nw
Gnarlwood Forest|#6 n;#3 nw;w;n;#4 e;s;w;sw;s;sw;#2 s;e;#2 se;#2 e;n
'''
# A second way in that you gave for a place that already had directions
ALT_DIRECTIONS = '''
Old Thalos|#9 w;#2 nw;n;w;nw;w;#2 nw;#8 w;nw;#3 w;nw;w;#2 nw;#2 w;#2 sw;w;sw;#5 w
'''
